import 'dart:async';

import 'package:dompet_sampah/src/constans/constant.dart';
import 'package:dompet_sampah/src/features/master_screen.dart';
import 'package:flutter/material.dart';

import 'src/features/auth/signin_screen.dart';

void main() {
  runApp(const MaterialApp(
    home: LandingPage(),
  ));
}

class LandingPage extends StatefulWidget {
  const LandingPage();

  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => SigninPage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor:
            MyColors.buttonBlue, // Set background color to transparent
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const FlutterLogo(
                  size: 150), // Replace with your logo or desired content
              const SizedBox(height: 24),
              const Text(
                'Dompet Sampah',
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}
