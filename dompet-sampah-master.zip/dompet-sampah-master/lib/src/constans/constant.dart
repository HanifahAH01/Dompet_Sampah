import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

class MyColors {
  static const Color buttonBlue = Color.fromARGB(255, 134, 160, 230);
  static const Color goldColor = Color(4294946705);
}

class MyIcons {
  static const IconData inActiveHome = Iconsax.home_2;
  static const IconData activeHome = Iconsax.home_25;
  static const IconData activeMap = Iconsax.map5;
  static const IconData inActiveMap = Iconsax.map_14;
  static const IconData activeWallet = Iconsax.wallet5;
  static const IconData inActiveWallet = Iconsax.wallet_14;
  static const IconData activeProfile = Iconsax.profile_circle5;
  static const IconData inActiveProfile = Iconsax.profile_circle4;
}
