import 'package:dompet_sampah/src/constans/constant.dart';
import 'package:flutter/material.dart';

class TrashPickUpPage extends StatefulWidget {
  const TrashPickUpPage({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _TrashPickUpPageState createState() => _TrashPickUpPageState();
}

class _TrashPickUpPageState extends State<TrashPickUpPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Angkut Sampah"),
          backgroundColor: MyColors.buttonBlue,
        ),
        body: Center(child: Text("Angkut sampah")));
  }
}
