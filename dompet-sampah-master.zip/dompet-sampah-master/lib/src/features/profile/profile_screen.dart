import 'package:confirm_dialog/confirm_dialog.dart';
import 'package:dompet_sampah/main.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';

import '../../constans/constant.dart';
import '../notification/notification_screen.dart';

class ProfilePageContent extends StatelessWidget {
  const ProfilePageContent({super.key});

  void _showConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Keluar'),
          content: Text('Apakah anda yakin ingin keluar?'),
          actions: <Widget>[
            TextButton(
              child: Text('Tidak'),
              onPressed: () {
                Navigator.of(context).pop(false); // Cancel the dialog
              },
            ),
            TextButton(
              child: Text('Ya'),
              onPressed: () {
                // Perform logout operation
                // ...
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            LandingPage())); // Close the dialog and proceed with logout
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () => _onBackButtonProcessed(context),
        child: Scaffold(
          appBar: AppBar(
            title: Text(
              "Profil",
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
            backgroundColor: MyColors.buttonBlue,
            actions: <Widget>[
              IconButton(
                icon: Icon(
                  Icons.notifications,
                  color: Colors.white,
                ),
                onPressed: () {
                  // Add your notification icon onPressed logic here
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => PageNotificationsStateless()));
                },
              ),
            ],
          ),
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    Stack(
                      children: [
                        Container(
                            width: 130,
                            height: 130,
                            decoration: BoxDecoration(
                                border:
                                    Border.all(width: 4, color: Colors.white),
                                boxShadow: [
                                  BoxShadow(
                                      spreadRadius: 2,
                                      blurRadius: 10,
                                      color: Colors.black.withOpacity(0.1))
                                ],
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: NetworkImage(
                                        "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500")))),
                        Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              child: Icon(
                                Iconsax.edit,
                                color: Colors.white,
                              ),
                              height: 40,
                              width: 40,
                              decoration: BoxDecoration(
                                  color: MyColors.buttonBlue,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      width: 4, color: Colors.white)),
                            ))
                      ],
                    ),
                  ],
                ),
                Expanded(
                    child: Container(
                        width: MediaQuery.of(context).size.width * 0.8,
                        height: 300,
                        child: Form(
                            child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            TextFormField(
                              // controller: () {},
                              // validator: (value) {},
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                label: Text("nama"),
                              ),
                            ),
                            TextFormField(
                              // controller: () {},
                              // validator: (value) {},

                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                label: Text("email"),
                              ),
                            ),
                            TextFormField(
                              // controller: () {},
                              // validator: (value) {},

                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                label: Text("password"),
                              ),
                            ),
                            TextFormField(
                              // controller: () {},
                              // validator: (value) {},
                              maxLines: 3,
                              decoration: InputDecoration(
                                border: OutlineInputBorder(),
                                label: Text("alamat"),
                              ),
                            ),
                            Padding(
                                padding: EdgeInsets.symmetric(horizontal: 1),
                                child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      OutlinedButton(
                                          style: OutlinedButton.styleFrom(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 35),
                                            // shape: RoundedRectangleBorder(
                                            //     borderRadius:
                                            //         BorderRadius.circular(
                                            //             20.0))
                                          ),
                                          onPressed: () {
                                            _showConfirmationDialog(context);
                                          },
                                          child: Text(
                                            "Keluar",
                                            style: TextStyle(
                                                color: Colors.red,
                                                letterSpacing: 2),
                                          )),
                                      ElevatedButton(
                                          onPressed: () {},
                                          child: Text(
                                            "Update",
                                            style: TextStyle(letterSpacing: 2),
                                          ),
                                          style: ElevatedButton.styleFrom(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 35),
                                              // shape: RoundedRectangleBorder(
                                              //     borderRadius:
                                              //         BorderRadius.circular(
                                              //             20.0)),
                                              backgroundColor:
                                                  MyColors.buttonBlue))
                                    ])),
                          ],
                        ))))
              ],
            ),
          ),
        ));
  }
}

Future<bool> _onBackButtonProcessed(BuildContext context) async {
  bool exitApp = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Keluar"),
          content: Text("Apakah anda yakin?"),
          actions: <Widget>[
            TextButton(
                onPressed: () {
                  Navigator.of(context).pop(false);
                },
                child: Text("Tidak")),
            TextButton(
                onPressed: () {
                  Navigator.of(context).pop(true);
                },
                child: Text("Ya"))
          ],
        );
      });

  return exitApp;
}
