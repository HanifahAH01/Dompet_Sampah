import 'package:flutter/material.dart';

import '../../constans/constant.dart';

class TrashSwitchPage extends StatefulWidget {
  const TrashSwitchPage({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _TrashSwitchPageState createState() => _TrashSwitchPageState();
}

class _TrashSwitchPageState extends State<TrashSwitchPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Tukar sampah"),
          backgroundColor: MyColors.buttonBlue,
        ),
        body: Center(child: Text("Tukar sampah")));
  }
}
