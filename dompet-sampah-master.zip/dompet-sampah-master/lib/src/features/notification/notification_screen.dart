import 'package:flutter/material.dart';

class PageNotificationsStateless extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: PageNotificationsStateful(),
    );
  }
}

class PageNotificationsStateful extends StatefulWidget {
  @override
  _PageNotificationState createState() => _PageNotificationState();
}

class _PageNotificationState extends State<PageNotificationsStateful>
    with SingleTickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            bottom: TabBar(
              indicatorSize: TabBarIndicatorSize.label,
              indicatorColor: Colors.black,
              tabs: [
                Tab(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Semua",
                      style: TextStyle(color: Colors.black),
                    ),
                    Padding(
                        padding: EdgeInsets.all(4),
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4.0),
                              color: Colors.black),
                          width: 17,
                          height: 17,
                          child: Text(
                            "12",
                            textAlign: TextAlign.center,
                          ),
                        ))
                  ],
                )),
                Tab(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Belum dibaca",
                      style: TextStyle(color: Colors.black),
                    ),
                    Padding(
                        padding: EdgeInsets.all(4),
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4.0),
                              color: Colors.grey),
                          width: 17,
                          height: 17,
                          child: Text(
                            "12",
                            textAlign: TextAlign.center,
                          ),
                        ))
                  ],
                )),
              ],
            ),
            title: const Text(
              'Notifikasi',
              style:
                  TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
            ),
            actions: <Widget>[
              InkWell(
                  onTap: () {},
                  child: Padding(
                      padding: EdgeInsets.all(20.0),
                      child: const Text(
                        "Tandai sudah dibaca",
                        style: TextStyle(
                            decoration: TextDecoration.underline,
                            color: Colors.black),
                      )))
            ],
          ),
          body: TabBarView(
            children: [
              Column(
                children: [
                  Expanded(
                      child: ListView.builder(
                          itemCount: 1,
                          itemBuilder: (context, index) {
                            return Container(
                              height: 80,
                              decoration: BoxDecoration(
                                color: Color.fromARGB(8, 106, 14, 110),
                              ),
                              child: Row(
                                children: [
                                  Padding(
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 20),
                                      child: Container(
                                        child: Text(
                                          "AZ",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                          ),
                                        ),
                                        width: 50,
                                        height: 50,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10.0),
                                          color: Colors.red,
                                        ),
                                      )),
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Row(children: [
                                        Text(
                                          "Aji Muhammad Zapar",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ]),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            "2h ago",
                                            textAlign: TextAlign.start,
                                            style:
                                                TextStyle(color: Colors.grey),
                                          ),
                                          Text("Driver",
                                              style:
                                                  TextStyle(color: Colors.grey))
                                        ],
                                      )
                                    ],
                                  )
                                ],
                              ),
                            );
                          }))
                ],
              ),
              Column(
                children: [],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
