import 'package:dompet_sampah/src/constans/constant.dart';
import 'package:dompet_sampah/src/features/home/home_screen.dart';
import 'package:dompet_sampah/src/features/map/map_screen.dart';
import 'package:dompet_sampah/src/features/profile/profile_screen.dart';
import 'package:dompet_sampah/src/features/wallet/wallet_screen.dart';
import 'package:flutter/material.dart';

import 'notification/notification_screen.dart';

class MasterPage extends StatelessWidget {
  const MasterPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: MasterPageStatefull(),
    );
  }
}

class MasterPageStatefull extends StatefulWidget {
  const MasterPageStatefull({super.key});

  @override
  State<MasterPageStatefull> createState() => _MasterPageElement();
}

class _MasterPageElement extends State<MasterPageStatefull> {
  int selectedIndex = 0;

  List<Widget> pages = [
    const HomePageContent(),
    const MapSample(),
    const WalletPageContent(),
    const ProfilePageContent(),
  ];

  void pageChanged(int index) {
    setState(() {
      selectedIndex = index;
    });
  }

  void _onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: pages.elementAt(selectedIndex)),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        shape: CircularNotchedRectangle(),
        child: Container(
          height: 56.0,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              IconButton(
                icon: Icon(
                  (selectedIndex == 0)
                      ? MyIcons.activeHome
                      : MyIcons.inActiveHome,
                  color: MyColors.buttonBlue,
                ),
                onPressed: () {
                  _onItemTapped(0);
                },
              ),
              IconButton(
                icon: Icon(
                  (selectedIndex == 1)
                      ? MyIcons.activeMap
                      : MyIcons.inActiveMap,
                  color: MyColors.buttonBlue,
                ),
                onPressed: () {
                  _onItemTapped(1);
                },
              ),
              IconButton(
                icon: Icon(
                  (selectedIndex == 2)
                      ? MyIcons.activeWallet
                      : MyIcons.inActiveWallet,
                  color: MyColors.buttonBlue,
                ),
                onPressed: () {
                  _onItemTapped(2);
                },
              ),
              IconButton(
                icon: Icon(
                  (selectedIndex == 3)
                      ? MyIcons.activeProfile
                      : MyIcons.inActiveProfile,
                  color: MyColors.buttonBlue,
                ),
                onPressed: () {
                  _onItemTapped(3);
                },
              ),
            ],
          ),
        ),
      ),
      // bottomNavigationBar: BottomNavigationBar(
      //   items: <BottomNavigationBarItem>[
      //     BottomNavigationBarItem(
      //       icon: Icon(
      //         (selectedIndex == 0) ? MyIcons.activeHome : MyIcons.inActiveHome,
      //         color: MyColors.buttonBlue,
      //       ),
      //       label: 'Home',
      //     ),
      //     BottomNavigationBarItem(
      //       icon: Icon(
      //         (selectedIndex == 1) ? MyIcons.activeMap : MyIcons.inActiveMap,
      //         color: MyColors.buttonBlue,
      //       ),
      //       label: 'Business',
      //     ),
      //     BottomNavigationBarItem(
      //       icon: Icon(
      //         (selectedIndex == 2)
      //             ? MyIcons.activeWallet
      //             : MyIcons.inActiveWallet,
      //         color: MyColors.buttonBlue,
      //       ),
      //       label: 'School',
      //     ),
      //     BottomNavigationBarItem(
      //       icon: Icon(
      //         (selectedIndex == 3)
      //             ? MyIcons.activeProfile
      //             : MyIcons.inActiveProfile,
      //         color: MyColors.buttonBlue,
      //       ),
      //       label: 'User',
      //     ),
      //   ],
      //   currentIndex: selectedIndex,
      //   // selectedIconTheme: ,
      //   onTap: _onItemTapped,
      // ),
    );
  }
}
