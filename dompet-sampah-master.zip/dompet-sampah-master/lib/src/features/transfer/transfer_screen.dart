import 'package:flutter/material.dart';
import 'package:flutter_credit_card/flutter_credit_card.dart';
import 'package:iconsax/iconsax.dart';

import '../../common_widgets/bank_card.dart';
import '../../common_widgets/card_widget.dart';
import '../../constans/constant.dart';

class TransferPage extends StatefulWidget {
  const TransferPage({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _TransferPageState createState() => _TransferPageState();
}

class _TransferPageState extends State<TransferPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Transfer"),
          backgroundColor: MyColors.buttonBlue,
        ),
        body: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            CreditCardWidget(
              cardNumber: "19893819312",
              expiryDate: "12-12-2024",
              cardHolderName: "Aji Muhammad Zapar",
              cvvCode: "12",
              showBackView: false,
              onCreditCardWidgetChange:
                  (CreditCardBrand) {}, //true when you want to show cvv(back) view
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 50),
              child: Row(
                children: [
                  Text(
                    "Pilih bank tujuan",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.all(10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                      child: CardWidgetBank(
                        path: "assets/img/bni.png",
                        color: Colors.white,
                      ),
                      onTap: () => {}),
                  InkWell(
                      child: CardWidgetBank(
                        path: "assets/img/btpn.png",
                        color: Colors.white,
                      ),
                      onTap: () => {}),
                  InkWell(
                      child: CardWidgetBank(
                        path: "assets/img/bri.png",
                        color: Colors.white,
                      ),
                      onTap: () => {})
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                InkWell(
                    child: CardWidgetBank(
                      path: "assets/img/mandiri.png",
                      color: Colors.white,
                    ),
                    onTap: () => {}),
                InkWell(
                    child: CardWidgetBank(
                      path: "assets/img/permata.png",
                      color: Colors.white,
                    ),
                    onTap: () => {}),
                InkWell(
                    child: CardWidgetBank(
                      path: "assets/img/bca.png",
                      color: Colors.white,
                    ),
                    onTap: () => {})
              ],
            ),
            Padding(
                padding:
                    EdgeInsets.only(right: 50, left: 50, top: 30, bottom: 10),
                child: Row(
                  children: [
                    Text(
                      "Masukan nomor rekening",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    )
                  ],
                )),
            Padding(
                padding: EdgeInsets.only(left: 10, right: 10, bottom: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ConstrainedBox(
                      constraints: BoxConstraints.tight(
                          Size(MediaQuery.of(context).size.width * 0.75, 50)),
                      child: TextFormField(
                        // controller: () {},
                        // validator: (value) {},
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey),
                              borderRadius: BorderRadius.circular(15)),
                          contentPadding: EdgeInsets.symmetric(horizontal: 10),
                          border: OutlineInputBorder(),
                          hintText: "Masukan nomor rekening tujuan",
                        ),
                      ),
                    ),
                    OutlinedButton(
                        onPressed: () {},
                        child: Text("Cek"),
                        style: OutlinedButton.styleFrom(
                            side: BorderSide(color: Colors.blue, width: 0.1)))
                  ],
                )),
            ElevatedButton(
                style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 50),
                    // shape: RoundedRectangleBorder(
                    //     borderRadius: BorderRadius.circular(20.0)),
                    backgroundColor: MyColors.buttonBlue),
                onPressed: () {},
                child: Text(
                  "Lanjut",
                  style: TextStyle(color: Colors.white),
                ))
          ],
        )));
  }
}
