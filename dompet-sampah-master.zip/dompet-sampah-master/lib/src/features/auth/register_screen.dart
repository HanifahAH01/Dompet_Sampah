import 'package:dompet_sampah/src/constans/constant.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import 'signin_screen.dart';

class RegisterPage extends StatelessWidget {
  const RegisterPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.all(50),
              child: Icon(
                Iconsax.share,
                size: 60,
                color: MyColors.buttonBlue,
              ),
            ),
            Container(
                width: MediaQuery.of(context).size.width * 0.8,
                height: 500,
                child: Form(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    TextFormField(
                      // controller: () {},
                      // validator: (value) {},
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        label: Text("nama"),
                      ),
                    ),
                    TextFormField(
                      // controller: () {},
                      // validator: (value) {},

                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        label: Text("email"),
                      ),
                    ),
                    TextFormField(
                      // controller: () {},
                      // validator: (value) {},

                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        label: Text("password"),
                      ),
                    ),
                    TextFormField(
                      // controller: () {},
                      // validator: (value) {},
                      maxLines: 5,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        label: Text("alamat"),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {},
                      child: Text(
                        "Daftar",
                        style: TextStyle(fontSize: 16),
                      ),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: MyColors.buttonBlue,
                          fixedSize:
                              Size(MediaQuery.of(context).size.width, 50)),
                    ),
                    Padding(
                        padding: EdgeInsets.all(10),
                        child: Row(
                          children: [
                            Text(
                              "Sudah punya akun? ",
                            ),
                            InkWell(
                              onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => SigninPage())),
                              child: Text(
                                "Masuk",
                                style: TextStyle(color: Colors.blue),
                              ),
                            )
                          ],
                        ))
                  ],
                )))
          ],
        ),
      )),
    );
  }
}
