import 'package:dompet_sampah/src/constans/constant.dart';
import 'package:dompet_sampah/src/features/master_screen.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import 'register_screen.dart';

class SigninPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.all(50),
              child: Icon(
                Iconsax.share,
                size: 60,
                color: MyColors.buttonBlue,
              ),
            ),
            Container(
                width: MediaQuery.of(context).size.width * 0.8,
                height: 300,
                child: Form(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: TextFormField(
                        // controller: () {},
                        // validator: (value) {},
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          label: Text("email"),
                        ),
                      ),
                    ),
                    TextFormField(
                      // controller: () {},
                      // validator: (value) {},

                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        label: Text("password"),
                      ),
                    ),
                    Padding(
                        padding: EdgeInsets.only(bottom: 20, top: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "Lupa password?",
                              style: TextStyle(color: Colors.blue),
                            )
                          ],
                        )),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => MasterPage()));
                      },
                      child: Text(
                        "Masuk",
                        style: TextStyle(fontSize: 16),
                      ),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: MyColors.buttonBlue,
                          fixedSize:
                              Size(MediaQuery.of(context).size.width, 50)),
                    ),
                    Padding(
                        padding: EdgeInsets.all(10),
                        child: Row(
                          children: [
                            Text(
                              "Belum punya akun? ",
                            ),
                            InkWell(
                              onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => RegisterPage())),
                              child: Text(
                                "Daftar",
                                style: TextStyle(color: Colors.blue),
                              ),
                            )
                          ],
                        ))
                  ],
                )))
          ],
        ),
      )),
    );
  }
}
