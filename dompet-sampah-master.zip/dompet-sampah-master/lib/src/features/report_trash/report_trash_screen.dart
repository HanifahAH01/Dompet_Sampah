import 'package:dompet_sampah/src/constans/constant.dart';
import 'package:flutter/material.dart';

class TrashReport extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Lapor sampah"),
        backgroundColor: MyColors.buttonBlue,
      ),
      body: Center(),
    );
  }
}
