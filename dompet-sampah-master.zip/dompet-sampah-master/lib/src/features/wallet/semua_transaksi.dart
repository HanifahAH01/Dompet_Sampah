import 'package:dompet_sampah/src/constans/constant.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

class SemuaTransaksi extends StatelessWidget {
  const SemuaTransaksi({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Semua transaksi"),
        backgroundColor: MyColors.buttonBlue,
      ),
      body: Center(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(10),
              child: Form(
                  child: Column(
                children: [
                  TextFormField(
                      // controller: () {},
                      // validator: (value) {},

                      decoration: InputDecoration(
                          prefixIcon: Icon(Iconsax.search_normal),
                          filled: true,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(40.0),
                              borderSide: BorderSide.none),
                          hintText: "Cari transaksi disini")),
                ],
              )),
            ),
            Expanded(
                child: ListView.builder(
                    itemCount: 10,
                    itemBuilder: (context, index) {
                      return Container(
                          decoration: BoxDecoration(
                              border: Border(
                            bottom: BorderSide(
                                color: Colors.grey,
                                width: 0.3,
                                style: BorderStyle.solid),
                          )),
                          child: ListTile(
                            leading: Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  image: AssetImage(
                                      'assets/img/profile.jpg'), // provide the image asset
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            title: Text("Tukar sampah"),
                            subtitle: Text("29 Juni 2023"),
                            trailing: Text(
                              "+ Rp 25.000",
                              style: TextStyle(color: Colors.green),
                            ),
                          ));
                    })),
          ],
        ),
      ),
    );
  }
}
