import 'package:dompet_sampah/src/constans/constant.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

class SemuaJadwal extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Semua jadwal"),
        backgroundColor: MyColors.buttonBlue,
      ),
      body: Center(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(10),
              child: Form(
                  child: Column(
                children: [
                  TextFormField(
                      // controller: () {},
                      // validator: (value) {},

                      decoration: InputDecoration(
                          prefixIcon: Icon(Iconsax.search_normal),
                          filled: true,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(40.0),
                              borderSide: BorderSide.none),
                          hintText: "silahkan ketik nama disini")),
                ],
              )),
            ),
            Expanded(
                child: ListView.builder(
                    itemCount: 10,
                    itemBuilder: (context, index) {
                      return Container(
                          decoration: BoxDecoration(
                              border: Border(
                            bottom: BorderSide(
                                color: Colors.grey,
                                width: 0.3,
                                style: BorderStyle.solid),
                          )),
                          child: ListTile(
                            leading: Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  image: AssetImage(
                                      'assets/img/profile.jpg'), // provide the image asset
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            title: Text("Puri Indah II"),
                            subtitle: Text("Jl. Pasir sereh, bandung"),
                            trailing: Text("10:00 WIB"),
                          ));
                    })),
          ],
        ),
      ),
    );
  }
}
