import 'package:dompet_sampah/src/constans/constant.dart';
import 'package:dompet_sampah/src/features/report_trash/report_trash_screen.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';

import '../../common_widgets/card_widget.dart';
import '../notification/notification_screen.dart';
import '../trash_pickup/trash_pickup_screen.dart';
import '../trash_switch/trash_switch_screen.dart';
import 'semua_jadwal.dart';

class HomePageContent extends StatefulWidget {
  const HomePageContent({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePageContent>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget buildBannerAtHome() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(
          padding:
              EdgeInsetsDirectional.symmetric(horizontal: 10, vertical: 40),
          child: Row(
            children: [
              const Text(
                "Hi, Aji Zapar",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 25),
              ),
              Image.asset("assets/img/waving-hand.png"),
              // RotationTransition(
              //     child: Image.asset("assets/img/waving-hand.png"),
              //     turns: Tween(
              //       begin: 0.0,
              //       end: 1.0,
              //     ).animate(_controller)),
            ],
          ),
        ),
        Padding(
          padding:
              EdgeInsetsDirectional.symmetric(horizontal: 10, vertical: 10),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            InkWell(
              onTap: () {
                showModalBottomSheet(
                    context: context,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(25.0),
                      ),
                    ),
                    builder: (BuildContext context) {
                      return SizedBox(
                          height: 300,
                          width: MediaQuery.of(context).size.width,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Align(
                                alignment: Alignment.topRight,
                                child: IconButton(
                                  icon: Icon(Iconsax.close_circle5),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                ),
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Image.asset("assets/img/dollar-shadow.png"),
                                  Padding(
                                      padding: EdgeInsets.all(5.0),
                                      child: Text(
                                        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum",
                                        textAlign: TextAlign.justify,
                                      ))
                                ],
                              ),
                            ],
                          ));
                    });
              },
              child: Card(
                color: MyColors.buttonBlue,
                elevation: 4,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Image.asset('assets/img/dollar.png'),
                        const Text(
                          "1500",
                          style: TextStyle(
                              fontSize: 16, color: MyColors.goldColor),
                        ),
                      ],
                    )),
              ),
            ),
            InkWell(
              onTap: () {
                showModalBottomSheet(
                    context: context,
                    shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(25.0),
                      ),
                    ),
                    builder: (BuildContext context) {
                      return SizedBox(
                        height: 300,
                        width: MediaQuery.of(context).size.width,
                        child: ListView(
                          children: [
                            Column(
                              children: [
                                Align(
                                  alignment: Alignment.topRight,
                                  child: IconButton(
                                    icon: Icon(Iconsax.close_circle5),
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                  ),
                                ),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Image.asset(
                                        "assets/img/gold-medal-shadow.png"),
                                    Padding(
                                        padding: EdgeInsets.all(5.0),
                                        child: Text(
                                          "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum",
                                          textAlign: TextAlign.justify,
                                        ))
                                  ],
                                ),
                              ],
                            )
                          ],
                        ),
                      );
                    });
              },
              child: Card(
                color: MyColors.buttonBlue,
                elevation: 4,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Image.asset(
                          'assets/img/gold-medal.png',
                          width: 25,
                          height: 25,
                        ),
                        const Text(
                          "Emas",
                          style: TextStyle(
                              fontSize: 16, color: MyColors.goldColor),
                        ),
                      ],
                    )),
              ),
            ),
          ]),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    DateTime now = DateTime.now();
    String formattedDate = DateFormat('EEEE, d MMMM yyyy').format(now);
    return Scaffold(
        appBar: AppBar(
          elevation: 0,
          foregroundColor: Colors.white,
          backgroundColor: Colors.white10,
          actions: <Widget>[
            IconButton(
              icon: Icon(
                Icons.notifications,
                color: MyColors.buttonBlue,
              ),
              onPressed: () {
                // Add your notification icon onPressed logic here
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => PageNotificationsStateless()));
              },
            ),
          ],
        ),
        body: Column(children: [
          Padding(
            padding: EdgeInsets.all(10),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(
                      formattedDate,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 16),
                      textAlign: TextAlign.left,
                    )
                  ],
                ),
                const Row(
                  children: [
                    Icon(Iconsax.location),
                    Text("Jl. Setiabudhi No. 28, Kota Bandung")
                  ],
                ),
              ],
            ),
          ),
          Container(
              width: MediaQuery.of(context).size.width * 0.9,
              height: 200,
              decoration: BoxDecoration(
                color: MyColors.buttonBlue,
                borderRadius: BorderRadius.circular(20),
              ),
              child: buildBannerAtHome()),
          Padding(
            padding: EdgeInsets.symmetric(
                horizontal: MediaQuery.of(context).size.width * 0.15,
                vertical: MediaQuery.of(context).size.height * 0.03),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    InkWell(
                        onHover: (value) {
                          setState(() {
                            _isHovered = value;
                          });
                        },
                        child: CardWidget(
                          icon: Iconsax.warning_2,
                          color: (_isHovered ? Colors.grey : Colors.white),
                        ),
                        onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => TrashReport()))),
                    Text("Lapor sampah", style: TextStyle(fontSize: 10))
                  ],
                ),
                Column(
                  children: [
                    InkWell(
                        onHover: (value) {
                          setState(() {
                            _isHovered = value;
                          });
                        },
                        child: CardWidget(
                          icon: Iconsax.truck,
                          color: (_isHovered ? Colors.grey : Colors.white),
                        ),
                        onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => TrashPickUpPage()))),
                    Text("Angkut sampah", style: TextStyle(fontSize: 10))
                  ],
                ),
                Column(
                  children: [
                    InkWell(
                        onHover: (value) {
                          setState(() {
                            _isHovered = value;
                          });
                        },
                        child: CardWidget(
                          icon: Iconsax.arrow_swap,
                          color: (_isHovered ? Colors.grey : Colors.white),
                        ),
                        onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => TrashSwitchPage()))),
                    Text(
                      "Tukar Sampah",
                      style: TextStyle(fontSize: 10),
                    )
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding:
                EdgeInsetsDirectional.symmetric(horizontal: 10, vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Jadwal angkut",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                InkWell(
                  child: Text(
                    "Lihat semua",
                    style: TextStyle(color: Colors.blue),
                  ),
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => SemuaJadwal())),
                )
              ],
            ),
          ),
          Expanded(
              child: ListView.builder(
                  itemCount: 10,
                  itemBuilder: (context, index) {
                    return Container(
                        decoration: BoxDecoration(
                            border: Border(
                          bottom: BorderSide(
                              color: Colors.grey,
                              width: 0.3,
                              style: BorderStyle.solid),
                        )),
                        child: ListTile(
                          leading: Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                image: AssetImage(
                                    'assets/img/profile.jpg'), // provide the image asset
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          title: Text("Puri Indah II"),
                          subtitle: Text("Jl. Pasir sereh, bandung"),
                          trailing: Text("10:00 WIB"),
                        ));
                  })),
        ]));
  }
}
