import 'package:flutter/material.dart';

class CardWidgetBank extends StatelessWidget {
  final String path;
  final Color color;
  const CardWidgetBank({super.key, required this.path, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
        width: 80,
        height: 80,
        child: Card(
          color: color,
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Image.asset(path),
          ),
        ));
  }
}
