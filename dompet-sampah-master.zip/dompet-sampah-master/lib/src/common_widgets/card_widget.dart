import 'package:dompet_sampah/src/constans/constant.dart';
import 'package:flutter/material.dart';

class CardWidget extends StatelessWidget {
  final IconData icon;
  final Color color;
  const CardWidget({super.key, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: color,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Icon(
            icon,
            color: MyColors.buttonBlue,
          )),
    );
  }
}
