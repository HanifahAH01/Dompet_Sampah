package com.example.dompet_sampah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
